let users = JSON.parse(localStorage.getItem("users")) || [];

// تسجيل المستخدم الجديد
document.getElementById("registerForm")?.addEventListener("submit", function(event) {
    event.preventDefault();
    
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let userType = document.getElementById("userType").value;

    if (users.some(user => user.email === email)) {
        alert("البريد الإلكتروني مسجل بالفعل!");
        return;
    }

    users.push({ name, email, password, userType });
    localStorage.setItem("users", JSON.stringify(users));

    alert("تم إنشاء الحساب بنجاح!");
    window.location.href = "index.html";
});

// تسجيل الدخول
document.getElementById("loginForm")?.addEventListener("submit", function(event) {
    event.preventDefault();

    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    let user = users.find(user => user.email === email && user.password === password);

    if (user) {
        alert(`مرحبًا ${user.name}!`);
        window.location.href = "doctors.html";
    } else {
        alert("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
    }
});

// عرض خريطة الأطباء
function initMap() {
    let map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 30.0444, lng: 31.2357 }, // القاهرة كمثال
        zoom: 12
    });

    let doctors = [
        { name: "دكتور أحمد", lat: 30.05, lng: 31.22 },
        { name: "دكتور محمد", lat: 30.03, lng: 31.24 }
    ];

    doctors.forEach(doctor => {
        new google.maps.Marker({
            position: { lat: doctor.lat, lng: doctor.lng },
            map,
            title: doctor.name
        });
    });
}
